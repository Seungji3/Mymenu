package sungil.mymenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import sungil.mymenu.databinding.ActivityBuyBinding
import sungil.mymenu.databinding.ActivityMainBinding

class BuyActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBuyBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBuyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val BuyIntent = intent
        val in1 = BuyIntent.getIntExtra("t1",9)
        val in2 = BuyIntent.getIntExtra("t2",9)
        val in3 = BuyIntent.getIntExtra("t3",9)
        val in4 = BuyIntent.getIntExtra("t4",9)
        val in5 = BuyIntent.getIntExtra("t5",9)
        val in6 = BuyIntent.getIntExtra("t6",9)
     //   val count = BuyIntent.getIntExtra("cnt",9)


        binding.first.text=in1.toString()
        binding.second.text=in2.toString()
        binding.third.text=in3.toString()
        binding.fourth.text=in4.toString()
        binding.fifth.text=in5.toString()
        binding.sixth.text=in6.toString()
//        binding.tvTotal.text="${count}원"
        var num : Int = (in1*3500)+(in2*4000)+(in3*4500)+(in4*4000)+(in5*3500)+(in6*4000)
        binding.tvTotal.text="${num}원"


        
    }
}