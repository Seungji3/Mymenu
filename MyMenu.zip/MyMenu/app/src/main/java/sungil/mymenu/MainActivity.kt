package sungil.mymenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.Glide
import sungil.mymenu.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2022/05/%EC%B4%88%EC%BD%94%ED%81%AC%EB%A6%BC%ED%94%84%EB%9D%BC%ED%8E%98-450x588.png")
            .into(binding.ivMenu1)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2022/05/%EB%94%B8%EA%B8%B0%ED%81%AC%EB%A6%BC%ED%94%84%EB%9D%BC%ED%8E%98-450x588.png")
            .into(binding.ivMenu2)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2018/06/ICED-%EC%99%84%EC%A0%84%EC%B4%88%EC%BD%94-450x588.png")
            .into(binding.ivMenu3)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2018/06/ICED-%EB%AF%BC%ED%8A%B8%EC%B4%88%EC%BD%94%EB%9D%BC%EB%96%BC-450x588.png")
            .into(binding.ivMenu4)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2018/06/%EB%AF%B8%EC%88%AB%EA%B0%80%EB%A3%A8-450x588.png")
            .into(binding.ivMenu5)

        Glide.with(this)
            .load("https://paikdabang.com/wp-content/uploads/2018/06/%EB%A0%88%EB%AA%A8%EB%84%A4%EC%9D%B4%EB%93%9C-450x588.png")
            .into(binding.ivMenu6)

        binding.btnFirstMin.setOnClickListener(){//첫번째 버튼
            var first : Int = binding.tvFirst.text.toString().toInt()
            if(first<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                first--
                binding.tvFirst.text=first.toString()
            }else{
                first-=1
                binding.tvFirst.text=first.toString()
            }
        }
        
        binding.btnFirstPlu.setOnClickListener(){
            var first : Int = binding.tvFirst.text.toString().toInt()
            first++
            binding.tvFirst.text=first.toString()
        }
        
        
        binding.btnSecondMin.setOnClickListener(){//두번째 버튼
            var second : Int = binding.tvSecond.text.toString().toInt()
            if(second<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                second--
                binding.tvSecond.text=second.toString()
            }else{
                second-=1
                binding.tvSecond.text=second.toString()
            }
        }
        
        binding.btnSecondPlu.setOnClickListener(){
            var second : Int = binding.tvSecond.text.toString().toInt()
            second++
            binding.tvSecond.text=second.toString()
        }
        
        
        binding.btnThirdMin.setOnClickListener(){//세번째 버튼
            var third : Int = binding.tvThird.text.toString().toInt()
            if(third<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                third--
                binding.tvThird.text=third.toString()
            }else{
                third-=1
                binding.tvThird.text=third.toString()
            }
        }
        
        binding.btnThirdPlu.setOnClickListener(){
            var third : Int = binding.tvThird.text.toString().toInt()
            third++
            binding.tvThird.text=third.toString()
        }
        
        
        binding.btnFourthMin.setOnClickListener(){//네번째 버튼
            var fourth : Int = binding.tvFourth.text.toString().toInt()
            if(fourth<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                fourth--
                binding.tvFourth.text=fourth.toString()
            }else{
                fourth-=1
                binding.tvFourth.text=fourth.toString()
            }
        }
        
        binding.btnFourthPlu.setOnClickListener(){
            var fourth : Int = binding.tvFourth.text.toString().toInt()
            fourth++
            binding.tvFourth.text=fourth.toString()
        }
        
        
        binding.btnFifthMin.setOnClickListener(){//다섯번째 버튼
            var fifth : Int = binding.tvFifth.text.toString().toInt()
            if(fifth<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                fifth--
                binding.tvFifth.text=fifth.toString()
            }else{
                fifth-=1
                binding.tvFifth.text=fifth.toString()
            }
        }
        
        binding.btnFifthPlu.setOnClickListener(){
            var fifth : Int = binding.tvFifth.text.toString().toInt()
            fifth++
            binding.tvFifth.text=fifth.toString()
        }
        
        
        binding.btnSixthMin.setOnClickListener(){//여섯번째 버튼
            var sixth : Int = binding.tvSixth.text.toString().toInt()
            if(sixth<1){
                Toast.makeText(this, "0보다 작은 수는 입력 받을 수 없습니다.",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
                sixth--
                binding.tvSixth.text=sixth.toString()
            }else{
                sixth-=1
                binding.tvSixth.text=sixth.toString()
            }
        }
        
        binding.btnSixthPlu.setOnClickListener(){
            var sixth : Int = binding.tvSixth.text.toString().toInt()
            sixth++
            binding.tvSixth.text=sixth.toString()
        }

        binding.btnCount.setOnClickListener(){ onclick() }

        binding.btnCash.setOnClickListener {
            val buyIntent = Intent(this, BuyActivity::class.java)
            buyIntent.putExtra("t1",binding.tvFirst.text.toString().toInt())
            buyIntent.putExtra("t2",binding.tvSecond.text.toString().toInt())
            buyIntent.putExtra("t3",binding.tvThird.text.toString().toInt())
            buyIntent.putExtra("t4",binding.tvFourth.text.toString().toInt())
            buyIntent.putExtra("t5",binding.tvFifth.text.toString().toInt())
            buyIntent.putExtra("t6",binding.tvSixth.text.toString().toInt())
           // buyIntent.putExtra("cnt",binding.tvCount.text.toString().substring(0,binding.tvCount.text.length-1).toInt())
            startActivity(buyIntent)
        }
    }


    private fun onclick(){

        var first : Int = binding.tvFirst.text.toString().toInt()
        var second : Int = binding.tvSecond.text.toString().toInt()
        var third : Int = binding.tvThird.text.toString().toInt()
        var fourth : Int = binding.tvFourth.text.toString().toInt()
        var fifth : Int = binding.tvFifth.text.toString().toInt()
        var sixth : Int = binding.tvSixth.text.toString().toInt()
        
        var count : Int = (first*3500)+(second*4000)+(third*4500)+(fourth*4000)+(fifth*3500)+(sixth*4000)
        binding.tvCount.text="${count}원"
    }
}